# Mums' Night Out

A tiny, mobile-first web app for organising a monthly mums' evening — and, for Barnes, daytime walks with newborns. No sign-up — open a private WhatsApp link, add your name once, then tick when you're free.

Two groups (**French Mums** and **Barnes Mums**) stay fully separate. Only the organiser sees both.

## Stack

- Next.js (App Router) + TypeScript + Tailwind
- Supabase (Postgres + Auth magic link for admin)
- Deploy on Vercel

## Quick local demo (no Supabase)

```bash
npm install
cp .env.example .env.local
# leave Supabase vars empty for in-memory mode
npm run dev
```

Open [http://localhost:3456](http://localhost:3456). Members use their private WhatsApp link (`/g/…`). Organiser login is at `/admin/login` (demo email `admin@example.com` when Supabase is unset). Group links live on the admin dashboard.

```bash
npm test          # group separation tests
```

## Production setup (non-developer friendly)

### 1. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) → New project.
2. Open **SQL Editor** → paste and run `supabase/migrations/001_init.sql`, then `002_day_meetups_and_availability.sql`.
3. Run `supabase/seed.sql` (creates the two groups + invite tokens).
4. From your laptop (with Node installed), seed the shows/venues:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://YOUR.supabase.co \
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY \
npm run seed
```

5. In **Project Settings → API**, copy:
   - Project URL → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon` `public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (keep secret)

6. In **Authentication → URL configuration**, add your site URL and redirect:
   - Site URL: `https://your-app.vercel.app`
   - Redirect: `https://your-app.vercel.app/api/auth/callback`

### 2. Deploy on Vercel

1. Push this repo to GitHub and import it in Vercel.
2. Set environment variables:

| Name | Value |
|------|--------|
| `NEXT_PUBLIC_SUPABASE_URL` | from Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | from Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | from Supabase |
| `ADMIN_EMAIL` | your email (magic-link login) |
| `NEXT_PUBLIC_SITE_URL` | `https://your-app.vercel.app` |
| `CRON_SECRET` | optional, random string for the monthly cron |
| `ANTHROPIC_API_KEY` | optional, Phase 5 show refresh |

3. Deploy. Open `/admin/login`, enter `ADMIN_EMAIL`, click the magic link.
4. Add member names per group. Copy each private link from **Links** (or regenerate).
5. Send the WhatsApp message from **Open voting**.

### 3. Important security notes

- Private links look like `/g/FrMumsK7x9…` — **never** `/g/french` or `/g/barnes`.
- RLS is on; the anon key cannot read tables. The server uses the service role and always filters by `group_id` from the invite token.
- After first deploy, regenerate invite tokens from `/admin` so the seed tokens are not public forever.

## How a night works

1. **Vote dates** — mums tick every evening they're free (you can pick more than one; autosave).
2. **Results** — organiser picks the winning date.
3. **Pick the plan** — heart ideas (shows / dinner for French; drinks / food for Barnes). Hearts are preferences — if something can't be booked, the organiser tries the next favourite. Venues can have open days, an availability note, and short member comments.
4. **It's on** — ticket card with details; organiser marks **Done** (option becomes `seen`, added to history).

Barnes can also open a **day walk** round: mums vote mornings/afternoons; the tally shows without venue picking.

## Files to know

- `supabase/migrations/001_init.sql` — schema + RLS
- `supabase/migrations/002_day_meetups_and_availability.sql` — day walks + open days / comments
- `supabase/seed.sql` — groups
- `scripts/seed.ts` — venues & shows
- `DECISIONS.md` — choices made while building
- `tests/separation.test.ts` — Barnes cannot see French data (and vice versa)

## Optional: monthly show refresh

Vercel Cron hits `/api/cron/refresh-shows` on the 1st of each month. With `ANTHROPIC_API_KEY` set, wire Claude + web search to insert French shows as `status = 'pending'` for admin approval (never re-adding `seen` titles).
