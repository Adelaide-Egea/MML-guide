import type { Metadata, Viewport } from 'next';
import { Figtree, Fraunces } from 'next/font/google';
import './globals.css';
import { SiteFooter } from '../components/SiteFooter.tsx';
import { TrialBeacon } from '../components/TrialBeacon.tsx';

const display = Fraunces({
  subsets: ['latin'],
  weight: ['300', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-display-loaded',
  display: 'swap',
});

const ui = Figtree({
  subsets: ['latin'],
  variable: '--font-ui-loaded',
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL('https://domela.app'),
  title: 'Domela — the household guide',
  description: 'Everything they need while you are not there.',
  openGraph: {
    title: 'Domela — the household guide',
    description: 'Everything you need while they are away.',
    type: 'website',
  },
  twitter: { card: 'summary_large_image' },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f6f1e9' },
    { media: '(prefers-color-scheme: dark)', color: '#1a201d' },
  ],
};

const THEME_SCRIPT = `
try {
  var stored = localStorage.getItem('theme');
  var dark = stored ? stored === 'dark'
    : window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (dark) document.documentElement.setAttribute('data-theme', 'dark');
} catch (e) {}
`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${ui.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
        <style>{`:root{
          --font-display: var(--font-display-loaded), Georgia, serif;
          --font-ui: var(--font-ui-loaded), -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }`}</style>
      </head>
      <body>
        <TrialBeacon />
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
